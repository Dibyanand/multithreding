import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

class Thread3 extends Thread {
	private CountDownLatch latch;

	public Thread3(CountDownLatch latch) {
		super("Thread1");
		this.latch = latch;
	
	}

	public void run() {
		for (int i = 1; i < 9; i++) {
			System.out.println("in for, current GetCount =    " + latch.getCount());
			try {
				
				Thread.sleep((long) (Math.random() * 1000));
				if ( (i % 3) ==0) {
					System.out.println(Thread.currentThread().getName() + " i is multiple 3");
				//	latch.countDown();
				}
				latch.countDown();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println(Thread.currentThread().getName() + " - " + i);
		}
	}
}

public class Lab3_CountDownLatch {
	public static void main(String[] args) throws InterruptedException, BrokenBarrierException {
		CountDownLatch latch = new CountDownLatch(4);
		Thread t1 = new Thread3(latch);
		t1.start();
		latch.await();
		System.out.println("after  await method ...  " + latch.getCount());
		
	}
}
