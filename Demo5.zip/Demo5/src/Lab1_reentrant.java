import java.util.concurrent.locks.ReentrantLock;

class Balance {
	private int count = 0;

	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}

class Buyer extends Thread {
	private Balance bal;
 private ReentrantLock mylock;
	
	
	public Buyer(Balance bal, ReentrantLock mylock) {
	super();
	this.bal = bal;
	this.mylock = mylock;
}


	public void run(){
		System.out.println("Buyer, before lock GetHoldCount =" + mylock.getHoldCount()+", QueueLength  " + mylock.getQueueLength());
		mylock.lock();
		System.out.println("Buyer, after lock GetHoldCount =" + mylock.getHoldCount() +", QueueLength  " + mylock.getQueueLength());
		int curbal  = this.bal.getCount();
		curbal++;
		this.bal.setCount(curbal);
		System.out.println("Buyer , current balance = " + this.bal.getCount());
		mylock.unlock();
		System.out.println("Buyer, after unlock GetHoldCount =" + mylock.getHoldCount() +", QueueLength  " + mylock.getQueueLength());
		
		}
}

class Seller extends Thread {
	private Balance bal;
	 private ReentrantLock mylock;
		

	public Seller(Balance bal, ReentrantLock mylock) {
		super();
		this.bal = bal;
		this.mylock = mylock;
	}


	public void run(){
		System.out.println("Seller, GetHoldCount =" + mylock.getHoldCount() +", QueueLength  " + mylock.getQueueLength());
		mylock.lock();
		System.out.println("Seller, GetHoldCount =" + mylock.getHoldCount() +", QueueLength  " + mylock.getQueueLength());
		
		int curbal  = this.bal.getCount();
		curbal--;
		this.bal.setCount(curbal);
		System.out.println("Seller , current balance = " + this.bal.getCount());
		mylock.unlock();
		}
}

public class Lab1_reentrant {


	public static void main(String[] args) {
		Balance bal = new Balance();
		 ReentrantLock mylock = new ReentrantLock();
		for (int i = 0; i< 10;i++){
			Thread t1 = new Buyer(bal,mylock);
			Thread t2 = new Seller(bal,mylock);
			t1.start();
			t2.start();
		}
		
	//	System.out.println("Current Balance = " + bal.getCount());
	}

}
