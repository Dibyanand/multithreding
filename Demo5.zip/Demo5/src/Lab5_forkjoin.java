import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import java.util.function.Predicate;

class MyRecurTask extends RecursiveTask<List<String>>{

	private List<String> list;
	private Predicate<String> pred;
	
	public MyRecurTask(List<String> list, Predicate<String> pred) {
		this.list = list;
		this.pred = pred;
	}

	@Override
	protected List<String> compute() {
		List<String> returnlist = new ArrayList<String>();
		if (list.size() < 100)
		{
			System.out.println("Thread = " + Thread.currentThread().getName() + "   less than 100, do it ");
			for (int i = 0; i< list.size();i++){
				if (pred.test(list.get(i))){
					returnlist.add(list.get(i));
				}
			}
		}
		else{
			System.out.println("In else, current size = "  +list.size());
			int size = list.size();
			List<MyRecurTask> tasklist = createTaskList();
			tasklist.forEach(task-> task.fork());
			tasklist.forEach(task-> returnlist.addAll(task.join()));
		}
		return returnlist;
	}
	
	public List<MyRecurTask> createTaskList(){
		// create multiple tasks
		List<MyRecurTask> tasklist = new ArrayList<>();
		int size = list.size();
		System.out.println("in createTaskList , current list size = " + size);
		MyRecurTask subtask1 = new MyRecurTask(list.subList(0, size/2), pred);
		MyRecurTask subtask2 = new MyRecurTask(list.subList(size/2, size), pred);
		tasklist.add(subtask1);
		tasklist.add(subtask2);
		return tasklist;
	}
	
}

public class Lab5_forkjoin {

	public static void main(String[] args) {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		List<String> list = new ArrayList();	
		for (int i = 0; i< 99999999; i++){
			list.add("str"+i);
		}
		Predicate<String> pred  =(s)->s.length()>5;
		ForkJoinPool pool = new ForkJoinPool(8);
		MyRecurTask task = new MyRecurTask(list, pred);
		List sortedlist = pool.invoke(task);
		

	}

}
