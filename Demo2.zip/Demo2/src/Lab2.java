import java.util.Scanner;

class Balance {
	int amount;
}

public class Lab2 {

	public static void main(String[] args) {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();

		Balance bal = new Balance();
		Runnable deposit = () -> {
			System.out.println("in start of deposit, current balance = " + bal.amount);
			try {
				Thread.sleep(500);
			} catch (Exception e) {
			}

			synchronized (bal) {
				bal.amount++;
				System.out.println("Take tdump");
			
				System.out.println("in end of deposit, current balance = " + bal.amount);
			}

		};
		Runnable widraw = () -> {
			System.out.println("in start of widraw, current balance = " + bal.amount);
			try {
				Thread.sleep(500);
			} catch (Exception e) {
			}

			synchronized (bal) {
				bal.amount--;
				System.out.println("in end of widraw, current balance = " + bal.amount);
			}

		};

		for (int i = 1; i <= 5; i++) {
			Thread deposit1 = new Thread(deposit);
			Thread widraw1 = new Thread(widraw);
			deposit1.setName("DepositThread");
			widraw1.setName("WidrawThread");
			deposit1.start();
			widraw1.start();
		}
		// System.out.println("After both the threads " + bal.amount);
	}

}
