
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
class Thread1 extends Thread
{
	String str1;
	String str2;
	
	public Thread1(String str1, String str2) {
		super("Thread1");
		this.str1 = str1;
		this.str2 = str2;
	}

	@Override
	public void run() {
		System.out.println("Thread1 Start of Run  ....");
		synchronized (str1) {
				System.out.println("Thread1, str1 synchronized, waiting for str2");
				try { 	Thread.sleep(2500); 			} catch (Exception e) { 				}
				synchronized (str2) {
					System.out.println("Thread1 str1, str2 both synchronized...");
				}
				System.out.println("Thread1, str1 synchronized, str2 released");
		}
		System.out.println("Thread1, str1 released, str2 released");
	}
}
class Thread2 extends Thread
{
	String str1;
	String str2;
	
	public Thread2(String str1, String str2) {
		super("Thread2");
		this.str1 = str1;
		this.str2 = str2;
	}

	@Override
	public void run() {
		System.out.println("Thread2 Start of Run  ....");
		synchronized (str1) {
				System.out.println("Thread2, str1 synchronized, waiting for str2");
				try { 	Thread.sleep(2500); 			} catch (Exception e) { 				}
				synchronized (str2) {
					System.out.println("Thread2 str1, str2 both synchronized...");
				}
				System.out.println("Thread2, str1 synchronized, str2 released");
		}
		System.out.println("Thread2, str1 released, str2 released");
	}
}
public class Lab4 {
public static void main(String[] args) throws Exception {
	System.out.println("start of main, waiting for a number input");
	Scanner scanner = new Scanner(System.in);
	scanner.nextInt();
	String str1 ="StringOne";
	String str2 = "StringTwo";
	Thread t1 = new Thread1(str1, str2);
	Thread t2 = new Thread2(str1, str2);
	t1.start();
	t2.start();

}
}
