import java.util.Scanner;

class MyThread1 extends Thread
{
	private String str;
	public MyThread1(String str) {
		super(str);	
		this.str = str;
			
	}
@Override
public void run() {
	String str = "";
	for (int i = 0; i< 999999999;i++)
		{
			str+= "a";
			if ((i %100)==0) {
				str ="a";
			}
		}
	System.out.println("Finished "+ this.getName());
}	
}
public class Lab1 {

	public static void main(String[] args) {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		Thread t1 = new MyThread1("+");
		t1.setPriority(Thread.MAX_PRIORITY);
		Thread t2 = new MyThread1("x");
		t1.start();
		t2.start();
		for (int i = 0; i< 999999999;i++)
		{
		if ((i %100)==0) 
			System.out.print("m");
		}	
		System.out.println("\n\nend of main");
	}

}
