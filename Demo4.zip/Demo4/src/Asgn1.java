import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;


class AsgnThread implements Runnable{
	@Override 
	public void run(){
		for (int i = 1; i<= 10;i++){
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("in " + Thread.currentThread().getName() + " and i  = " + i);
			if (i==5)
					throw new RuntimeException("Problem in execution");
		}
	
	}
}
public class Asgn1 {

	public static void main(String[] args) throws Exception {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
	
	//	ExecutorService service  = Executors.newSingleThreadExecutor();
		ExecutorService service  = Executors.newFixedThreadPool(2);
		service.submit(new AsgnThread());
		service.submit(new AsgnThread());
		service.submit(new AsgnThread());
		service.shutdown();
		
		
	}

}
