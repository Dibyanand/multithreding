import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


class Lab3Helper implements Runnable{
	@Override 
	public void run(){
		System.out.println("in run...." + Thread.currentThread().getName() +  " at " + new Date());
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
public class Lab3 {

	public static void main(String[] args) throws Exception {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		ScheduledExecutorService service1  = Executors.newScheduledThreadPool(1);
   // 	service1.schedule(new Lab3Helper(), 5, TimeUnit.SECONDS);
		//service1.scheduleAtFixedRate(new Lab3Helper(),5, 1, TimeUnit.SECONDS);
		service1.scheduleWithFixedDelay(new Lab3Helper(),5, 1, TimeUnit.SECONDS);

		System.out.println("end of main");
		//service1.shutdown();
	
		
	}

}
