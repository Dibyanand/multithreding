import java.util.Scanner;

class MyThread3 extends Thread
{
	private String str;
	public MyThread3(String str) {
			this.str = str;
	}
@Override
public void run() {
	for (int i = 0; i< 10000;i++)
		{
		System.out.print(str);
		try { 			Thread.sleep(1); 		} catch (InterruptedException e) { 		}
		if ((i %80)==0)
			System.out.println();
		}
}	
}
public class Lab3 {

	public static void main(String[] args) {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		Thread t1 = new MyThread3("+");
		Thread t2 = new MyThread3("-");
		Thread t3 = new MyThread3("*");
		Thread t4 = new MyThread3("/");
		Thread t5 = new MyThread3("%");
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		
		System.out.println("\n\nend of main");
	}
}
