class MyThread4 implements Runnable{
	private String str;
	public MyThread4(String str) {
			this.str = str;
	}
	
	@Override
	public void run() {
		for (int i = 0; i< 10000;i++)
		{
		System.out.print(str );
		try { 			Thread.sleep(1); 		} catch (InterruptedException e) { 		}
		if ((i %80)==0)
			System.out.println();
		}
}	
}

public class Lab4 {

	public static void main(String[] args) {
		Thread t1 = new Thread(new MyThread4("+"));
		Thread t2 = new Thread(new MyThread4("x"));
		t1.start();
		t2.start();
		

	}

}
