import java.util.Scanner;

class MyThread2 extends Thread
{
	private String str;
	public MyThread2(String str) {
			this.str = str;
	}
@Override
public void run() {
	for (int i = 0; i< 10000;i++)
		{
		System.out.print(str);
		if ((i %80)==0)
			System.out.println();
		}
}	
}
public class Lab2 {

	public static void main(String[] args) {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		Thread t1 = new MyThread2("+");
		Thread t2 = new MyThread2("x");
		t1.start();
		t2.start();
		
		System.out.println("\n\nend of main");
	}

}
