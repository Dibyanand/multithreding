import java.util.Scanner;

class Thread2 extends Thread
{
@Override
public void run() {
	for (int i = 0;i< 5;i++)
	{
		System.out.println("in for " + i);
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}	


}
public class Lab2 {

	public static void main(String[] args) {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();

		System.out.println("in start of main...");
		Thread2 t1 = new Thread2();
		t1.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		System.out.println("in end  of main...");
	}

}
