import java.util.Scanner;

class Thread4_1 extends Thread
{
@Override
public void run() {
	String str  ="a";
	for (int i = 0;i< 99999;i++)
	{
		str+=  "a";
		if ((i % 1000)==0)
			{ 
			System.out.println("before  yield....");
			yield();
			System.out.println("after yield....");
			}
		if ((i %100)==0)
			System.out.println("Thread4_1 -  :" +  i);
	}
}	
}
class Thread4_2 extends Thread
{
@Override
public void run() {
	String str  ="b";
	for (int i = 0;i< 999;i++)
	{
		System.out.println("Thread4_2 -  :" +  i);
	/*	str+=  "b";
		if ((i %1000)==0)
			System.out.println("Thread4_2 -  :" +  i);*/
	}
}	
}
public class Lab4 {

	public static void main(String[] args) {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		long st = System.currentTimeMillis();
		System.out.println("in start of main...");
		Thread4_1 t1 = new Thread4_1();
		Thread4_2 t2 = new Thread4_2();
		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long et = System.currentTimeMillis();
		
		System.out.println("in end  of main..." + (et-st));
		
	}

}
