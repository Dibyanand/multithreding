class Account{
	private String name;
	private double amt;
	
	public Account(String name, double amt) {
		this.name = name;
		this.amt = amt;
	}
	public double getAmt() {
		return amt;
	}
	public void setAmt(double amt) {
		this.amt = amt;
	}

}
class BankDeposit extends Thread{
	private Account acc;
	private DebitCard debit;
	public BankDeposit(Account acc, DebitCard debit) {
		super("Deposit");
		this.acc = acc;
		this.debit = debit;
	}
	@Override
	public void run() {
		synchronized (acc) {
		this.acc.setAmt(this.acc.getAmt()+100);
		System.out.println("In Bank Deposit after adding 100, current balance = " + this.acc.getAmt());
		}
		if (this.acc.getAmt() >= 100)
		{
			synchronized (debit) {
				debit.notify();	
			}
			
		}
	}
}

class ATM extends Thread{
	private Account acc;
	public ATM(Account acc) {
		super("ATM");
		this.acc = acc;
	}
	@Override
	public void run() {
		synchronized (acc) {
			this.acc.setAmt(this.acc.getAmt()-100);
			System.out.println("In ATM after widrawing 100, current balance = " + this.acc.getAmt());	
		}
		
	}
}
class DebitCard extends Thread{
	private Account acc;
	public DebitCard(Account acc) {
		super("DebitCard");
		this.acc = acc;
	}
	@Override
	public void run() {
		if (this.acc.getAmt() <= 100)
		{
			try {
				System.out.println("in debit before wait ");
				synchronized (this) {
					this.wait(15000);
				}
				System.out.println("in debit after wait, ready to continue ");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		synchronized (acc) {
				this.acc.setAmt(this.acc.getAmt()-100);
		System.out.println("In Debit after widrawing 100, current balance = " + this.acc.getAmt());
		}
	}
}

public class Lab1 {

	public static void main(String[] args) throws InterruptedException {
		Account acc = new Account("Simran", 0);
		DebitCard debit = new DebitCard(acc);
		BankDeposit bd = new BankDeposit(acc,debit);
		ATM atm = new ATM(acc);
		
	//	bd.start();
	//	atm.start();
		debit.start();
		bd.start();
	Thread.sleep(2000);
		System.out.println("after 2 seconds sleep");
		synchronized (debit) {
			debit.notify();	
		}
		
	}

}
