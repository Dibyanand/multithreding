
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Lab3 {
public static void main(String[] args) throws Exception {
	System.out.println("start of main, waiting for a number input");
	Scanner scanner = new Scanner(System.in);
	scanner.nextInt();

//	List<String> list = new ArrayList<>();
	List list = Collections.synchronizedList(new ArrayList());
	Runnable add = ()->{
		list.add("str");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Current Size = " + list.size());
	};
	Thread[] tarray = new Thread[500];
	for (int i = 0; i< 500; i++){
		tarray[i] = new Thread(add);
		tarray[i].start();
	}
	for (int i = 0; i< 500; i++){
		tarray[i].join();
	}
	System.out.println("in Main, Size of list = " + list.size());
}
}
