import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


class Lab2Helper implements Runnable{
	@Override 
	public void run(){
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("in run...." + Thread.currentThread().getName() +  " at " + new Date());
	
	}
}
public class Lab2 {

	public static void main(String[] args) throws Exception {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		ScheduledExecutorService service1  = Executors.newScheduledThreadPool(1);
    	service1.schedule(new Lab2Helper(), 5, TimeUnit.SECONDS);
		System.out.println("end of main");
		service1.shutdown();
	
		
	}

}
