import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

class Lab1Helper implements Callable<String>{
	@Override 
	public String call() throws Exception{
		Thread.sleep(100);
		System.out.println("in call...." + Thread.currentThread().getName() +  " at " + new Date());
		return "hello ";
	}
}
class Lab1Thread implements Runnable{
	@Override 
	public void run(){
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("in run...." + Thread.currentThread().getName() +  " at " + new Date());
	
	}
}
public class Lab1 {

	public static void main(String[] args) throws Exception {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
	//	ExecutorService service  = Executors.newSingleThreadExecutor();
	//	ExecutorService service  = Executors.newFixedThreadPool(5);
		ExecutorService service1  = Executors.newCachedThreadPool();
		ExecutorService service2  = Executors.newFixedThreadPool(5);
		Future<String> str = service1.submit(new Lab1Helper());
		System.out.println("before get ");
		System.out.println("Str = "  +  str.get(2,TimeUnit.SECONDS));
		System.out.println("after get ");
		List<Future<String>> list = new ArrayList<>();
		for (int i  = 0;i < 5;i++){
			list.add( service1.submit(new Lab1Helper()));
			Thread.sleep(100);
			service2.submit(new Lab1Thread());
		}
		list.forEach(e-> {
			try {
				System.out.println(e.get());
			} catch (InterruptedException | ExecutionException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		System.out.println("end of main");
		service1.shutdown();
		service2.shutdown();
		
	}

}
