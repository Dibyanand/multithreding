import java.util.Scanner;

public class Lab1 {

	public static void main(String[] args) {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();

		
		System.out.println("\n\nend of main");
	}

}
