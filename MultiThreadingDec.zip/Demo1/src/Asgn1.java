class AsgnThread extends Thread {
	static boolean flag = true;
	private String loc;
	public AsgnThread(String loc) {
		this.loc = loc;
	}

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			try { Thread.sleep((long) (Math.random() * 1000));	} catch (InterruptedException e) {}
			if (flag == false)
				break; 
			System.out.println("Current i = " + i + " for loc = " + loc);
		}
		if (flag == true) {
			System.out.println("Final Loc = " + loc);
			flag = false;
		}
	}
}

public class Asgn1 {

	public static void main(String[] args) {

		Thread t1 = new AsgnThread("LocA");
		Thread t2 = new AsgnThread("LocB");
		Thread t3 = new AsgnThread("LocC");
		t1.start();
		t2.start();
		t3.start();

	}

}
