
public class Lab5 {
public static void main(String[] args) {
	System.out.println("start of main");
	Runnable run1 =  () ->	System.out.println("in run  method ");
	Thread t1 = new Thread(run1);
	t1.start();
	System.out.println("\n\nend of main");
			
}
}
