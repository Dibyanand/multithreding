import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

class Thread1 extends Thread {
	private CyclicBarrier barrier;

	public Thread1(CyclicBarrier barrier) {
		super("Thread1");
		this.barrier = barrier;
	}

	public void run() {
		for (int i = 1; i < 15; i++) {
			try {
				Thread.sleep((long) (Math.random() * 1000));
				if ( (i % 3) ==0) {
					System.out.println(Thread.currentThread().getName() + " i is multiple 3");
					barrier.await();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			System.out.println(Thread.currentThread().getName() + " - " + i);
		}
	}
}

public class Lab2_CyclicBarrier {
	public static void main(String[] args) throws InterruptedException, BrokenBarrierException {
		CyclicBarrier barrier = new CyclicBarrier(2);
		Thread t1 = new Thread1(barrier);
		t1.start();
	/*	Thread t2 = new Thread1(barrier);
		t2.start();*/
		barrier.await();
		System.out.println("after 1CyclicBarrier await method ...  ");
		
	}
}
