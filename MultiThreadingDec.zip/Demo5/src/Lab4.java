import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Lab4 {

	public static void main(String[] args) {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
	List<String> list = new ArrayList();	
	for (int i = 0; i< 500000; i++){
		list.add("str"+i);
	}
//	list.stream().filter((s)->s.length()>5).forEach(System.out::println);
	
	list.parallelStream().filter((s)->s.length()>5).forEach(System.out::println);
	}

}
