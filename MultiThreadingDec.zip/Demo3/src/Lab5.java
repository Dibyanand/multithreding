import java.util.Scanner;

class Thread5_1 extends Thread
{
	public Thread5_1(ThreadGroup grp,String name) {
		super(grp,name);
	}
@Override
public void run() {
	String str  ="a";
	for (int i = 0;i< 9999;i++)
	{
				try {
				if (this.getName().equals("T1"))
					Thread.sleep(10);
				else
					Thread.sleep(5);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		str+=  "a";
		if ((i %1000)==0)
			System.out.println(this.getName()+ " :" +  i);
	}
}	
}

public class Lab5 {

	public static void main(String[] args) throws Exception {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		System.out.println("in start of main...");
		ThreadGroup grp = new ThreadGroup("MyGrp");
		Thread5_1 t1 = new Thread5_1(grp, "T1");
		Thread5_1 t2 = new Thread5_1(grp,"T2");
		t1.start();
		System.out.println(".............Current Active Count after t1= "+ grp.activeCount());
		t2.start();
		System.out.println(".............Current Active Count after t2= "+ grp.activeCount());
		
		Thread[] arr = new Thread[2];
		grp.enumerate(arr);
		for (Thread th : arr) {
			System.out.println("in for "+ th);
			synchronized (th) {
				System.out.println("waiting .... " + th.getName());
				th.wait(1000);
				System.out.println("wait over..." + th.getName());
			}
		
		Thread.sleep(2000);
		System.out.println(".............Current Active Count after 2 seconds= "+ grp.activeCount());
	
		}
		
		
		System.out.println("in end  of main..." );
	
	}

}
