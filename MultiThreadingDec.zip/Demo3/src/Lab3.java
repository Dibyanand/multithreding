import java.util.Scanner;

class Thread3 extends Thread
{
@Override
public void run() {
	for (int i = 0;i< 15;i++)
	{
		System.out.println("in for " + i);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}	


}
public class Lab3 {

	public static void main(String[] args) {
		System.out.println("start of main, waiting for a number input");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();

		System.out.println("in start of main...");
		Thread3 t1 = new Thread3();
		t1.setDaemon(true);
		t1.start();
		System.out.println("in end  of main...");
		
	}

}
